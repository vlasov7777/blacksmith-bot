# coding: utf-8

# BlackSmith-bot module.
# © simpleApps, 21.05.2012.
# This module contains main web\
# functions for site parsing.

import re

## HTML Unescape and <br> tag replace.
def uHTML(text):
	from HTMLParser import HTMLParser
	text = re.sub("</?br */?>", "\n", text)
	text = HTMLParser().unescape(text)
	del HTMLParser
	return text 
	
## Get HTML tag.
def getTag(tag, data):
	pattern = re.compile("<%(tag)s.*?>(.*?)</%(tag)s>" % vars(), flags=re.S+re.IGNORECASE)
	tagData = pattern.findall(data) or " "
	return tagData[0]
	
## IDNA tool.	
def IDNA(text, encode = True):
	try:
		if encode:
			text = unicode(text).encode("idna")
		else:
			text = unicode(text).decode("idna")
	except:
		pass
	return text

def IDNA(text, encode = True):
	if text.startswith("http"):		# Maybe it's a secured link (https)
		idFrom = text.find("/") + 2	# We have only 2 slashes
		text = text[idFrom::]
	try:
		if encode:
			text = unicode(text).encode("idna")
		else:
			text = unicode(text).decode("idna")
	except: pass
	return text