# coding: utf-8

# BlackSmith-bot module.
# © simpleApps, 21.05.2012.
# This module contains main web\
# functions for site parsing.

import re

UserAgents = {"OperaMini": "Opera/9.60 (J2ME/MIDP; Opera Mini/4.2.13337/724; U; ru)"} # Opera Mini 4.2 User-Agent

## HTML Unescape and <br> tag replace.
def uHTML(text):
	from HTMLParser import HTMLParser
	text = re.sub("</?br */?>", "\n", text)
	text = HTMLParser().unescape(text)
	del HTMLParser
	return text 
	
## Get HTML tag.
def getTag(tag, data):
	pattern = re.compile("<%(tag)s.*?>(.*?)</%(tag)s>" % vars(), flags=re.S+re.IGNORECASE)
	tagData = pattern.findall(data) or " "
	return tagData[0]
	
def stripTags(data, subBy = str(), pattern = "<[^<>]+>"):
	pattern = re.compile(pattern)
	return pattern.sub(subBy, data)
	
## IDNA tool.
def IDNA(text, encode = True):
	if text.startswith("http"):		# Maybe it's a secured link (https)
		idFrom = text.find("/") + 2	# We have only 2 slashes
		text = text[idFrom::]
	try:
		if encode:
			text = unicode(text).encode("idna")
		else:
			text = unicode(text).decode("idna")
	except: pass
	return text
	
## Format size.
def byteFormat(or_bytes):
	kbytes, bytes  = divmod(or_bytes, 1024)
	mbytes, kbytes = divmod(kbytes, 1024)
	gbytes, mbytes = divmod(mbytes, 1024)
	tbytes, gbytes = divmod(gbytes, 1024)
	text = str()
	if bytes:
		text = u"%d байт" % (bytes)
	if or_bytes >= 1024:
		text = u"%d kB %s" % (kbytes, text)
	if or_bytes >= 1048576:
		text = u"%d MB %s" % (mbytes, text)
	if or_bytes >= 1073741824:
		text = u"%d GB %s" % (gbytes, text)
	if or_bytes >= 1099511627776:
		text = u"%d TB %s" % (tbytes, text)
	return text