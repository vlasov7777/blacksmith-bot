# coding: utf-8

# BlackSmith-bot module.
# © simpleApps, 21.05.2012.
# This module contains main web\
# functions for site parsing.

import re

UserAgents = {"OperaMini": "Opera/9.60 (J2ME/MIDP; Opera Mini/4.2.13337/724; U; ru)"} # Opera Mini 4.2 User-Agent

## HTML Unescape and <br> tag replace.
import htmlentitydefs

edefs = dict()

for Name, Numb in htmlentitydefs.name2codepoint.iteritems():
	edefs[Name] = unichr(Numb)

del Name, Numb

compile_ehtmls = re.compile("&(#?[xX]?(?:[0-9a-fA-F]+|\w{1,8}));")

def uHTML(data):
	if data.count("&"):

		def e_sb(co):
			co = co.group(1)
			if co.startswith("#"):
				if chr(120) == co[1].lower():
					Char, c06 = co[2:], 16
				else:
					Char, c06 = co[1:], 10
				try:
					Numb = int(Char, c06)
					assert (-1 < Numb < 65535)
					Char = unichr(Numb)
				except:
					Char = edefs.get(Char, "&%s;" % co)
			else:
				Char = edefs.get(co, "&%s;" % co)
			return Char

		data = compile_ehtmls.sub(e_sb, data)
	return data
	
## Get HTML tag.
def getTag(tag, data):
	pattern = re.compile("<%(tag)s.*?>(.*?)</%(tag)s>" % vars(), flags=re.S+re.IGNORECASE)
	tagData = pattern.search(data)
	if tagData:
		tagData = tagData.group(1)
	return tagData or " "
	
def stripTags(data, subBy = str(), pattern = "<[^<>]+>"):
	pattern = re.compile(pattern)
	return pattern.sub(subBy, data)
	
## IDNA tool.
def IDNA(text, encode = True):
	if text.count("://"):		# Maybe it's a secured link (https)
		text = text.split("://")[1]
	try:
		if encode:
			text = unicode(text).encode("idna")
		else:
			text = unicode(text).decode("idna")
	except: 
		pass
	return text
	
## Format size.
def byteFormat(or_bytes):
	kbytes, bytes  = divmod(or_bytes, 1024)
	mbytes, kbytes = divmod(kbytes, 1024)
	gbytes, mbytes = divmod(mbytes, 1024)
	tbytes, gbytes = divmod(gbytes, 1024)
	text = str()
	if bytes:
		text = u"%d B" % (bytes)
	if or_bytes > 1024:
		text = u"%d kB %s" % (kbytes, text)
	if or_bytes > 1048576:
		text = u"%d MB %s" % (mbytes, text)
	if or_bytes > 1073741824:
		text = u"%d GB %s" % (gbytes, text)
	if or_bytes > 1099511627776:
		text = u"%d TB %s" % (tbytes, text)
	return text